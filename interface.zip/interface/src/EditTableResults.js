import React from 'react';


class EditTableResults extends React.Component {
  render() {
    return(
      this.props.queryData.map((user) => (
        <p>a</p>
      ))
    )
  }
}

export default EditTableResults;
