from django.db import models

# Create your models here.
class User(models.Model):
	customer_name = models.CharField(max_length = 200)
	customer_id = models.IntegerField(default = 0)
	customer_phone = models.IntegerField(default = 0)
	room_id = models.IntegerField(default = 0)
	num_bike = models.IntegerField(default = 1)
	bike_id = models.IntegerField(default = 0)
	parking_card_id = models.IntegerField(default = 0)
	customer_deposit = models.IntegerField(default = 0)
	start_date = models.DateTimeField(auto_now_add = True)

	image_profile = models.FileField(null = True, blank=True)
	image_cmnd = models.FileField(default = 0, blank=True)

	def __str__(self):
		return self.customer_name
