from user.models import User
from rest_framework import viewsets, permissions
from .serializer import UserSerializer
from django_filters import rest_framework as filters

# filter

class UserFilter(filters.FilterSet):

	class Meta:
		model = User
		fields = {
			'room_id' : ['iexact'],
			'customer_id' : ['iexact'],
			'customer_name' : ['icontains'],
		}

# Viewset
class UserViewSet(viewsets.ModelViewSet):
	queryset = User.objects.all()
	permissions_classes = [
		permissions.AllowAny
	]
	serializer_class = UserSerializer
	filterset_class = UserFilter
